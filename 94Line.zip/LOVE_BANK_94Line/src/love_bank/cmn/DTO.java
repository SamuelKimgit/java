package love_bank.cmn;

/**
 * 모든 domain의 Parent
 */
public class DTO {

}
